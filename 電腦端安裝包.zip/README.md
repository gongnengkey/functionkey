# 功能鍵遙控器 - 電腦端接收程式

## 系統需求
- Windows 7/8/10/11
- Java 8 或更高版本
- WiFi 或藍牙功能

## 快速安裝

### 方法1：一鍵安裝（推薦）
1. 下載 `install.bat`
2. 以管理員身份執行
3. 按照提示完成安裝

### 方法2：手動安裝
1. 安裝 Java：https://www.java.com/download/
2. 下載 `FunctionKeyReceiver.jar`
3. 雙擊執行

## 使用說明

### 啟動接收程式
1. 雙擊 `start_receiver.bat`
2. 程式會自動開啟防火牆
3. 記錄顯示的IP地址

### 設定開機自動啟動
1. 執行 `register_autostart.bat`
2. 重開機後會自動啟動

## 故障排除

**Q: 無法啟動程式**
A: 請確認已安裝 Java 8 或更高版本

**Q: 手機無法連接**
A: 請確認：
- 電腦和手機在同一WiFi網路
- 防火牆已允許程式通過
- IP地址輸入正確

**Q: 功能鍵無反應**
A: 請確認：
- 接收程式正在運行
- 手機已成功連接
- 沒有其他程式佔用功能鍵

## 技術支援
- 電子郵件：support@functionkey.com
- 網站：https://functionkey.com
- 問題回報：https://github.com/functionkey/issues
